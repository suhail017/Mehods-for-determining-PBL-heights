%take_home_exam_prb_3

%Initialize matlab

clc;
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Dashboard
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xa = 0;
xb = 20;
ya = 0;
yb = 1;


load ex2dat.mat

%normalize the y axis

f = f/max(f);
% Load the data

plot(t,f)
 xlim([xa xb])
 ylim([ya yb])
