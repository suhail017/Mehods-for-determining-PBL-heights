


close all
clc
clear all

% Part a
 
syms h f1 f2 f3 f4 f5 f6 
%        x = [-3*h;-2*h;-h;0;h];
        x= [-4*h;-3*h;-2*h;-h;0];
% x=[-2*h;-h;0;h;2*h];
%    x = [-2*h; -h ; 0; h ];
%  x=[-5*h/2; -3*h/2; -h/2; h/2; 3*h/2; 5*h/2];
X = [x.^0 x.^1 x.^2 x.^3 x.^4]
  inv_x = inv(X)
f= [f1;f2;f3;f4;f5];
% a =Y*f;
a = X\f;
% disp('The first derivation is')
% disp(a(2,:))
 
 disp('The Second derivation is')
 disp(2*a(3,:))
% 
 disp('The third derivation is ')
 disp(6*a(4,:))
%  
% 
% %Part b

