%Take home exam

%Gauss jordan inverse
%Submitted by suhail mahmud
%ID 80539798

%INITIALIZE MATLAB

clc;
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASH BOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Define a matrix
%A= [8.1 1.0 1.6 1.4 6.6; 9.1 2.8 9.7 4.2 0.4; 1.3 5.5 9.6 9.2 8.5;9.1 9.6 4.9 7.9 9.3 ; 6.3 9.6 8.0 9.6 6.8];

A = [1 2 3;4 5 6;7 8 0];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Solve Ax=b using gauss jordan method
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Determine the size

[M,N] = size(A);

if M~=N
    error ('Matrix size should be equal');
end

%Construct augmented matrix

U= [A eye(M,N)];
disp('Build augmented matrix is')
disp(U)
row =(1:5)';
dU = diag(U);
%Loop through all the rows


for m=1:M
           fprintf('divided row %d  by   %d\n',row(m),dU(m))

%disp(U(m,m))
    % Normalize by dividing by diagonal elements
    U(m,:) = U(m,:)/U(m,m);
    
    %Iterate through other rows
    for r=1:M

        if r~=m
         fprintf('Multiple the row %d  by element  %d\n and substract  row %d from %d\n ',row(m),U(r,m),row(r),row(m))

            U(r,:) = U(r,:) - U(r,m)*U(m,:);

        end


disp(U)

    end
end

%Extract final answer

iA = U(:,M+1:2*M);
x= U(:,M+1);

%Check the answer
diff = inv(A)-iA;

if diff > 0
    fprintf('the answer is wrong\n');
else
    fprintf('You are right\n');
end

%Calculate the unknown terms
% Unknown = iA*b;
disp('The final answer is ')
disp(iA)
