%hw11p3
%Initialize Matlab

clc
close all
clear all

