%demo_fdcoeff

%Initialize Matlab
clc;
close all;
clear all;

%define point positions
syms h f1 f2 f3;
%x=[-0.5*h, +0.5*h];
x=[-h 0 h];
%build x
X= [ones(length(x),1),x(:), x(:).^2];

%invert 
Y=inv(X);

%get polynomial coefficients
a=Y*[f1;f2;f3];

%Extract finite difference expression
fd0=simplify (a(1,:));
fd1=simplify (a(2,:));
fd2=simplify (2*a(3,:));
pretty(fd1)
pretty(fd0)
pretty(fd2)

