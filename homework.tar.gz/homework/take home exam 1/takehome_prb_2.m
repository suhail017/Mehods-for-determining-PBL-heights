%take home exam 1
%initialize matlab

clc;
close all;
clear all;



% example  
% X = 98:0.01:99;
% Y = @(X) ex2func(X);
% index = find(Y(X)==2);
% X_point = X(index);
% plot(X,Y_point,'-r')
% See graphically    
%  plot(Y(index),X_point,'o');
 
 
  
 x = linspace(98.760,98.766,1000);
 f =   @(x) ex2func(x);
  fx =f(x); 
  fx=single(fx);
%   fx = sprintf('%1.4f',fx);
%   fx=ones(1,fx);
% double val;
val = find(fx == 2.0000);
 fval = fx(val);
 %plot((f(x)(index)))
 plot(x,f(x));
 grid on;



% my_function = @(x) ex2func(x);
% % a = fzero(my_function,[-100 100]);
% % for i = -5:.01:5
% % 
% %     a = fzero(my_function,i)
% %     ind = int8((5.01+i)*100) 
% %     b(ind) = a;
% % end
% % result = unique(b)
% 
% b=ones(1,3);
% for i = -5:5 
% a = fzero(my_function,i); 
% if (b(end) == 0) && (b(end) ~= a) 
% b(length(b)) = a; 
% elseif (b(end) ~= a) && (abs((b(end) - a)) > .1) 
% b(length(b) + 1) = a; 
% end 
% end
