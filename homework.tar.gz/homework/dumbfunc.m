function y=dumbfunc(x)
 y=exp(x)-x-5;
 
% y=cot(x);
%  y=x.^2+x-2;
end

