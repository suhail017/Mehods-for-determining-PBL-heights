%hw5prb3
clc;
clear all;
close all;
x=linspace(-2,5,1000);
y=1+2*x-2*x.^2-4*x.^3;
plot(x,y)