 function [DVX,DVY,DDX,DDY] = tlder(NS,RES)
% TLDER Construct Matrix Derivative Operators on a 2D Grid
%
% [DVX,DVY,DDX,DDY] = tlder(NS,RES);
%
% INPUT ARGUMENTS
% ================
% NS [Nx Ny] grid size
% RES [dx dy] grid resolution of the 1X grid
%
% Note: For normalized grid coordinates, you may need to use
% [DVX,DVY,DDX,DDY] = tlder(NS,k0*RES);
%
% OUTPUT ARGUMENTS
% ================
% DVX, DVY Matrices that calculate derivatives for V
% DDX, DDY Matrices that calculate derivatives for E and D
%
% EXAMPLE CODE TO CALL TLDER
% ============================
% The following program generates the four derivative matrices for a
% grid that is 4 cells wide and 5 cells tall and where the cell size
% is 0.1 wide and 0.2 tall.
%


% % DEFINE GRID
% Nx = 3;
% Ny = 5;
% dx = 0.1;
% dy = 0.25;

% % BUILD DERIVATIVE MATRICES
%  NS = [Nx Ny];
%  RES = [dx dy];
% [DVX,DVY,DDX,DDY] = tlder(NS,RES);
% NS = [Nx Ny];
if NS(1) ==1
    DVX = sparse(NS(1)*NS(2),NS(1)*NS(2));
    DDX = sparse(NS(1)*NS(2),NS(1)*NS(2));
else
    
    DVX = sparse(NS(1)*NS(2),NS(1)*NS(2));
    DVX =spdiags(-ones(NS(1)*NS(2),1),0,DVX); %putting negetive one in sparse matrix
    a = ones(NS(1)*NS(2),1);
    for i = 1:NS(1):NS(1)*NS(2)
        a(i) = 0;
    end
    DVX =spdiags(a,+1,DVX); 
    DVX= DVX/(RES(1));
    
    
    DDX = sparse(NS(1)*NS(2),NS(1)*NS(2));
    DDX = spdiags(ones(NS(1)*NS(2),1),0,DDX);
    b =-ones(NS(1)*NS(2),1);
    for n = 1:NS(1):NS(1)*NS(2)
        b(n+NS(1)-1) = 0;
    end
    DDX = spdiags(b,-1,DDX);
    DDX = DDX/(RES(1));
 end


if NS(2)==1
    DVY = sparse(NS(1)*NS(2),NS(1)*NS(2));
    DDY = sparse(NS(1)*NS(2),NS(1)*NS(2));
else
    DVY = sparse(NS(1)*NS(2),NS(1)*NS(2));
    DVY = spdiags(-ones(NS(1)*NS(2),1),0,DVY);
    DVY = spdiags(ones(NS(1)*NS(2),1),NS(1),DVY);
    DVY= DVY/(RES(2));
    
    
    DDY = sparse(NS(1)*NS(2),NS(1)*NS(2));
    DDY = spdiags(ones(NS(1)*NS(2),1),0,DDY);
    DDY = spdiags(-ones(NS(1)*NS(2),1),-NS(1),DDY);
    DDY= DDY/(RES(2));
end





