%Homework8Problem2

%Initialize Matlab
clc;
close all;
clear all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Dashboard
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%initial values
x1 = 0;
x2 = 2*pi;
Nx = 1000; 
x = linspace(x1,x2,Nx);
dx = x(2) - x(1);

% Function to evaluate

f = cos(x);

% plot(x,f,'-r','LineWidth',2)
% hold on;

f = f(:);

% Using the Function Fdder1d 
[DX,DX2] = fdder1d(Nx,dx);
% DX(1,1:2) = [1 -1];
% DX(Nx,[Nx-1:Nx]) = [1 -1];
% DX2(1,1:3)=[1 -2 0];
% DX2(Nx,[Nx-2:Nx])=[0 -2 1];
yd = DX*f;
yd2 = DX2*f;

plot(x,f,'--r',x,yd,'*-g','Linewidth',2)
ylim([-1 1.5])
xlim([0 max(x)])
xlabel('x','FontSize',14)
ylabel('cos(x)','Rotation',0,'FontSize',14)
title('x vs cos(x)','FontSize',14);
legend('Original Function',' 1st Order Derivative','FontSize',10)


figure
plot(x,f,'--k',x,yd2,'*-b','Linewidth',2)
ylim([-1 1.5])
xlim([0 max(x)])
xlabel('x','FontSize',14)
ylabel('cos(x)','Rotation',0,'FontSize',14)
title('x vs cos(x)','FontSize',14);
legend('Original Function',' 2nd Order Derivative','FontSize',10)




