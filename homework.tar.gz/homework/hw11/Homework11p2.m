%Homework11

%Initialize matlab
clc
clear all
close all


% UNITS
millimeters = 1;
meters = 1e3 * millimeters;
% CONSTANTS
u0 = 1.2566370614e-6 * 1/meters;
e0 = 8.8541878176e-12 * 1/meters;
c0 = 299792458 * meters;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% STEP 1 -- DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TRANSMISSION LINE PARAMETERS
er = 6.0; %dielectric constant of substrate
a = 0.5*millimeters;
b = 10*millimeters;
N = 400;
t = linspace(a,b,N); %thickness of substrate
w = 3 * millimeters; %width of signal line
Zc = ones(1,N);
for i = 1:N
    h = t(i);
    [Z0] = microstrip(w,h,er);
    Zc(i) = Z0;
end
figure
plot(t,Zc)
axis  tight
line([0 1.881],[49.89 49.89],'color','k','linestyle',':');
line([1.881 1.881],[0 49.89],'color','k','linestyle',':');
line([0 5.357],[75 75],'color','k','linestyle',':');
line([5.357 5.357],[0 75],'color','k','linestyle',':');
title('Impedence VS Substrate Thickness','FontSize',12)
xlabel('Substrate Thickness (mm)','FontSize',12)
ylabel('Impedence of the transmission line (Ohms)','FontSize',12)
