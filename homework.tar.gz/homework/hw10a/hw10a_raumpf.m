%Initialize Matlab
clc
clear all
close all

% HW10a_Prob2.m
%
% EE 4386/5301 Computational Methods in EE
% University of Texas at El Paso
% Instructor: Dr. Raymond C. Rumpf
% INITIALIZE MATLAB
close all;
clc;
clear all;
% UNITS
millimeters = 1;
meters = 1e3 * millimeters;
% CONSTANTS
u0 = 1.2566370614e-6 * 1/meters;
e0 = 8.8541878176e-12 * 1/meters;
c0 = 299792458 * meters;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% STEP 1 -- DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TRANSMISSION LINE PARAMETERS
er = 6.0; %dielectric constant of substrate
h = 2 * millimeters; %thickness of substrate
w = 3 * millimeters; %width of signal line


% GRID PARAMETERS
Sx = 21 * millimeters; %physical size of grid along x
Sy = 14 * millimeters; %physical size of grid along y
Nx = 128; %number of grid points along x
Ny = 85; %number of grid points along y



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Step 2 build materials arrray
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Initail guess at resoultaion
dx = Sx/Nx;
dy = Sy/Ny;


%Snap grid to critical dimension

nx =ceil( w/dx);
dx = w/nx;

ny = ceil(h/dy);
dy = h/ny;


%recalculate the size
Sx = Nx*dx;
Sy = Ny*dy;

%Grid axis
xa = [0:Nx-1]*dx;
xa = xa-mean(xa);
ya = [0:Ny-1]*dy;


%Build ground
GND = zeros(Nx,Ny);
GND([1 Nx],:) = 1;
GND(:,[1 Ny]) = 1;

%Build Sig
SIG = zeros(Nx,Ny);
nx = round(w/dx);
nx1 = 1+floor((Nx-nx)/2);
nx2 = nx1+nx-1;
ny = round(h/dy);
ny = Ny-ny-1;
SIG(nx1:nx2,ny) = 1;


%Build ERxx and ERyy

ERxx = ones(Nx,Ny);
ERxx(:,ny+1:Ny) = er;
ERyy = ERxx;

%Show arrays
subplot(221);
imagesc(xa,ya,GND');
axis equal tight
colorbar
title('GND','FontSize',14)


subplot(222);
imagesc(xa,ya,SIG');
axis equal tight
colorbar
title('SIG','FontSize',14)

subplot(223);
imagesc(xa,ya,ERxx');
axis equal tight
colorbar
title('ERxx','FontSize',14)


subplot(224);
imagesc(xa,ya,ERyy');
axis equal tight
colorbar
colormap('Gray')
title('ERyy','FontSize',14)


