%INITIALIZE MATLAB
clc;
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%number of points
N=7;

%Number of values
x =[-4.69 -3.5 -1.17 0.26 2.05 2.69 4.31];
f= [-5.68 -7.37 -4.41 1.17 4.84 3.90 8.91];

%Set the x axis
xlow= -5;
xhigh = 5;

plot(x,f,'or')
for k=1:N
text(x(k),f(k),['  (', num2str(x(k)), ', ', num2str(f(k)), ')'])
end

hold on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Main Method
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%Changing the Matrix size
f= reshape(f,N,1);%changing it to column vector
Z= [x(:),ones(N,1)];%changing it to column vector


%Solve least square
f=Z.'*f;
Z=Z.'*Z;
a=Z\f;
fprintf ('The value of alpha is %f\n', a(1));
fprintf ('The value of beta is %f\n', a(2));


%Calculate xf and yf
xf=linspace (xlow,xhigh,N);
yf=a(1)*xf+a(2);

%Visualization
plot(xf,yf,'-b');
hold off;
title(' Linear regression','FontSize',12)
legend('measured data','fit line','Location' ,'NorthWest');
xlabel('x','FontSize',12)
ylabel('f','Rotation',0,'FontSize',12)





