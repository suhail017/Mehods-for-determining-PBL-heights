%Initialize matlab
%secant method
clc;
close all;
clear all;

%Open a figure window
 figure('Color','w')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%initialize guess
x1 = 0;
x2 = 10;
tol = 1e-6;

%Function
func=@ex2func

%Graphics Limits
xa=2;
xb=5;
ya= 0;
yb=2;


%Calculate the high resolution
 xh=linspace(xa,xb,10);
 %fh=func(xh);

%evaluate the functiom
%

f1=double(func(x1));
f2=double(func(x2));



%main loop

dx =inf;
iter=0;
while abs(dx)>tol
    
    %update iteration number
    iter=iter+1;
    %step
    dx = (x2-x1)*f2/(f2-f1);
    %Visualize
%      x2=x2-dx;
%     plot(xh,fh,'-k','Linewidth',2);
%      hold on;
%      plot(x1,f1,'ok');
%      plot(x2,f2,'ok');
%      xx=[xa xb];
%      yy=[0 0];
%      line(xx,yy,'Color','k','Linewidth',2);
%     p1=[x1;f1];
%     p2=[x2;f2];
%     dp=p1-p2;
%     dp=dp/norm(dp);
%     p1=p1+100*dp;
%     p2=p2-100*dp;
%     
%     line([p1(1) p2(1)],[p1(2) p2(2)],'Color','r','Linewidth',1.5);
%     
%     %     fill(0.001*xc+x1,0.001*yc+f1,0.7*[1 1 1]);
%     %     fill(0.001*xc+x2,0.001*yc+f2,0.7*[1 1 1]);
%     xx=[x1 x1];
%     yy=[]
%      hold off;
%      xlim([xa xb]);
%      ylim([ya yb]);
%     
%     return
    %adjust
    x1=x2;
    f1=f2;
    %update the root
    x2 =x2-dx;
    f2=func(x2);
end
xr=x2;