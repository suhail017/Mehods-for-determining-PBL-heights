%demo least square
%INITIALIZE MATLAB
clc;
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%number of points
N=1000;

%Number 

%Make up problem
m=1.5;
b=-0.5;
x= linspace(-1,5,N);
y=m*x+b;


%Add noise
ra=0.5+rand(1,N);
%rb = 0.9+0.2*rand(1,N); % making the noise from 0.9 to 1.1
y=ra+y;

plot(x,y,'.')

return
%Forget answer
clear m b ra rb;


%Step 1
f= reshape(y,N,1);%changing it to column vector
Z= [x(:),ones(N,1)];%changing it to column vector

%Solve least square
f=Z.'*f;
Z=Z.'*Z;
a=Z\f;

%Calculate xf and yf
xf=linspace (x(1),x(N),1000);
yf=a(1)*xf+a(2);

plot(x,y,'.')
hold on;
plot(xf,yf,'-r','LineWidth',6);
hold off;





