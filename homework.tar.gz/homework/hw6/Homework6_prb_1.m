%Homework6_prb_1

%Initialize matlab
%secant method
clc;
close all;
clear all;

%Open a figure window
%  figure('Color','w')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%initialize guess
x1 =[0 1 5] ;
x2 = [1 2 6];

tol = 1e-6;

%Function
func=@hw6func;

%Graphics Limits
xa=0;
xb=10;
ya= 0;
yb=2;


%Calculate the high resolution
 xh=linspace(xa,xb,100);
 fh=func(xh);

%evaluate the functiom


f1=func(x1);



%main loop

dx =inf;
iter=0;
while abs(dx)>tol
    f2=func(x2);
    
    
    %update iteration number
    iter=iter+1;
    %step
    dx = (x2-x1).*f2/(f2-f1);
    
    
    %Visualize
    x2=x2-dx;
    
    plot(xh,fh,'-k','Linewidth',2);
    hold on;
    plot(x1,f1,'or');
    plot(x2,f2,'ok');
    xx=[xa xb];
    yy=[0 0];
     line(xx,yy,'Color','g','Linewidth',2);
    hold off;
    xlim([xa xb]);
%     ylim([ya yb]);
    
    %adjust
    x1=x2;
    f1=f2;
    %update the root
    x2 =x2-dx;
      f2=func(x2);
end
xr=x2;
fprintf ('The root is %.6f\n',xr)
