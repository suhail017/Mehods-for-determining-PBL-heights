function [ DX,DX2 ] = fdderld(Nx,dx)
%FDDERLD              One-Dimensional Finite-Difference Derivation
%                     Operators Using Dirichlet Boundary Conditions

d = ones(1,Nx-1)
Diag1 = diag(d,1)
Diag2 = diag(-d,-1)
DX = Diag1 + Diag2; 
DX = DX/(2*dx)
I = 2*eye(Nx,Nx)
DX2 = diag(d,-1) + diag(d,1) - I
DX2 = DX2/(dx)^2;
end

