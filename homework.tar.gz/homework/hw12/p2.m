%HW12
% initialize Matlab
close all;
clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% dashboard
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tol = 1e-3;
err = inf;
ITER = 0;
x0 = 0;
y0 = 0;
x = [x0; y0];
alpha = 0.1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% steepest ascent
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% function
func =@(x,y) (3.5*x + 2*y + x.^2 - x.^4 - 2*x*y - y.^2) ;

% Main Loop
while err>tol
    
    ITER = ITER + 1;
    g = [(3.5 + 2*x(1) - 4*x(1).^3 -2*x(2)); (2 - 2*x(1) - 2*x(2))];
    x = x + alpha.*g;
    err = sqrt(g(1)^2 + g(2)^2);
end

%%%%%%%%%%%%%%%%%%%%%%%%%
%% Result
%%%%%%%%%%%%%%%%%%%%%%%%%
xe = x(1);
ye = x(2);
fxy =func(xe, ye);

fprintf('The value of (xe,ye) is (%f,%f) , And value f(xe,ye) is %f\n',xe,ye,fxy)




%HW12P2B.m
% initialize Matlab
close all;
clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% dashboard
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tol = 1e-3;
err = inf;
ITER = 0;
x0 = 0;
y0 = 0;
x = [x0; y0];
alpha = 0.1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% steepest ascent
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% function
func =@(x,y) (-8*x + x.^2 + 12*y + 4*y.^2 - 2*x*y);


% Main Loop
while err>tol
    
    ITER = ITER + 1;
    g = [(3.5 + 2*x(1) - 4*x(1).^3 -2*x(2)); (2 - 2*x(1) - 2*x(2))];
    x = x + alpha.*g;
    err = sqrt(g(1)^2 + g(2)^2);
end

%%%%%%%%%%%%%%%%%%%%%%%%%
%% Result
%%%%%%%%%%%%%%%%%%%%%%%%%
xe = x(1);
ye = x(2);
fxy =func(xe, ye);

fprintf('The value of (xe,ye) is (%f,%f) , And value f(xe,ye) is %f\n',xe,ye,fxy)