% HW10a_Prob2.m
%
% EE 4386/5301 Computational Methods in EE
% University of Texas at El Paso
% Instructor: Dr. Raymond C. Rumpf
% INITIALIZE MATLAB
close all;
clc;
clear all;
% UNITS
millimeters = 1;
meters = 1e3 * millimeters;
% CONSTANTS
u0 = 1.2566370614e-6 * 1/meters;
e0 = 8.8541878176e-12 * 1/meters;
c0 = 299792458 * meters;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% STEP 1 -- DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TRANSMISSION LINE PARAMETERS
er = 6.0; %dielectric constant of substrate
h = 2 * millimeters; %thickness of substrate
w = 3 * millimeters; %width of signal line


% GRID PARAMETERS
Sx = 21 * millimeters; %physical size of grid along x
Sy = 14 * millimeters; %physical size of grid along y
Nx = 128; %number of grid points along x
Ny = 85; %number of grid points along y

dx = Sx/Nx;
dy = Sy/Ny;

xa = 0:Nx; %array of points along x
ya = 0:Ny; %array of points along y


%Building the arrays of zeros and ones

sry = (h/Sy)*Ny; 
sry1 = round(sry);
sry2 = Ny - sry1 - 1;
srx = (w/Sx)*Nx;
srx1 = round(srx);
srx2 = (Nx - srx1)/2;
srx3 = srx1 + srx2;


x = zeros(1,Nx);
y = zeros(1,Ny);
[Y,X] = meshgrid(y,x);
Z = zeros(Nx+1,Ny+1);
Z(srx2:srx3,sry2) = 1;


figure('Color' , 'w' );
hold on;
subplot(2,2,1)
pcolor(xa,ya,Z')
set(gca,'Ydir','reverse')
xlim([-0.1 Nx]);
ylim([-0.1 Ny]);
axis off;
cmap = [ 1 1 1; 0.6 0.6 0.6];
colormap(cmap);
title('SIG','FontSize',14)

Z1 = zeros(Nx+1,Ny+1);
Z1(1:Nx,1) = 1;
Z1(1:Nx,Ny) = 1;
Z1(1,1:Ny) = 1;
Z1(Nx,1:Ny) = 1;


subplot(2,2,2)
pcolor(xa,ya,Z1')
set(gca,'Ydir','reverse')
xlim([-0.1 Nx]);
ylim([-0.1 Ny]);
axis off;
cmap = [ 1 1 1; 0.6 0.6 0.6];
colormap(cmap);
title('GND','FontSize',14)

Z3 = zeros(Nx+1,Ny+1);
for i=73:85
Z3(1:Nx,i) = 6;
end

subplot(2,2,3)
pcolor(xa,ya,Z3')
set(gca,'Ydir','reverse')
xlim([-0.1 Nx]);
ylim([-0.1 Ny]);
axis off;
cmap = [ 1 1 1; 0.6 0.6 0.6];
colormap(cmap);
title('ERxx','FontSize',14)


subplot(2,2,4)
pcolor(xa,ya,Z3')
set(gca,'Ydir','reverse')
xlim([-0.1 Nx]);
ylim([-0.1 Ny]);
axis off;
cmap = [ 1 1 1; 0.6 0.6 0.6];
colormap(cmap);
title('ERyy','FontSize',14)
hold off;


