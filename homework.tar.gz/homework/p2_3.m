% Home work problem 2.3

%Initialize Matlab

clc;
close all
clear all

%Units and Measurements

meters = 1;
centimeters = 1e-2 * meters;
millimeters = 1;
inches = 2.54 * centimeters;
feet = 12 * inches;
seconds = 1;
hertz = 1/seconds;
kilohertz = 1e3 * hertz;
megahertz = 1e6 * hertz;
gigahertz = 1e9 * hertz;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

xa=425.5*2* millimeters;

ya=425.5*2* millimeters;

Nx = 512;

Ny = 512;

wage_value = [20 1 18 4 13 6 ...
    10 15 2 17 3 19 7 16 8 11 14 9 12 5];

l = length(wage_value);

%Setup axis

dx = round(xa/Nx);
dy = round(ya/Ny);

xa = (0:Nx - 1)*dx;
xa = xa - mean(xa);
ya = (0:Ny - 1)*dy;
ya = ya - mean(ya);

%Setup meshgrid

[X , Y] = meshgrid(xa,ya);


%Making the wedges
dtheta = 2*pi/l;
THETA = (pi+ atan2(Y,X))/2*pi;
THETA = THETA -min(THETA(:));
THETA = THETA /max(THETA(:));
THETA = ceil (20*THETA);



%Making the circles

CIR= X.^2 + Y.^2;
cir7=ones(Nx,Ny);
 
cir7= cir7.*THETA;

r6 = 323.8 *millimeters;
cir6 = CIR>=r6^2;
cir7(cir6) = 0;  %The outermost circle

r5 = 304.8*millimeters;
cir5 = CIR<r6^2 & CIR>=r5^2;
cir7(cir5) = 40;

r4 = 203.2*millimeters;
 cir4 = CIR<r5^2 & CIR>=r4^2;
 cir7(cir4) = 20;

r3 = 184.1*millimeters;
cir3 = CIR<r4^2 & CIR>=r3^2;
cir7(cir3) = 3*THETA(cir3);

r2 = 31.8*millimeters;

r1 = 14.2*millimeters;

cir1 = CIR<r2^2 & CIR>=r1^2;
cir7(cir1) = 25;

cir0 = CIR<r1^2;
cir7(cir0) = 50; %inner most circle



%visualization

figure;
imagesc(xa,ya,cir7');
colorbar;
axis equal tight;