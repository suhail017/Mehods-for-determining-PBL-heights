%Final exam

%Problem 5
%Initialize Matlab

clc
close all 
clear all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Dashboard
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

e1 = 40;
 eb = 6.0;
e2 = 2.4;

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% Function to evaluate
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
%Problem a
t1 = ((e1-eb)/(e1+2*eb));
t2 = ((e2-eb)/(e2+2*eb));
f = -t2/(t1-t2);
% 
%Problem b
f = linspace(0,1,1000);
syms eb
f1 = (-((e2-eb)/(e2+2*eb))/(((e1-eb)/(e1+2*eb))-((e2-eb)/(e2+2*eb))));
eb1 = finverse(f1);
eb = (141*f)/5 + (19881*f.^2 - 12408*f + 3136).^(1/2)/5 - 44/5;
plot(f,eb,'LineWidth',2,'Color','g')
xlabel('Fill Fraction, f' , 'FontSize' ,14 );
ylabel('Effective Dielectric Constact, \epsilon_B' , 'FontSize' ,14 );
title('\epsilon_B VS. f' , 'FontSize' ,18);
line([0.2766 0.2766],[0 6],'color','k','linestyle',':','LineWidth',2);
line([0 0.2766],[6 6],'color','k','linestyle',':','LineWidth',2);


Problem c
e1 = 200;
eb = 20;
e2 = 2.4;
t1 = ((e1-eb)/(e1+2*eb));
t2 = ((e2-eb)/(e2+2*eb));
f = -t2/(t1-t2);