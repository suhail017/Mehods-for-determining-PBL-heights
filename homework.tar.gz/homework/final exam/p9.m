
%Initialize Matlab

clc
clear all
close all
% 
% % Problem 9a
% 
% x= linspace(-4,10);
% func= (x.^(2)-0.1*x.^(3)+5*cos(x));
% [nmax,maxAt,maxValues,nmin,minAt,minValues] = peakFinder(func,x);
% plot(x,func,'Linewidth',2,'Color','g')
% line([6.32 6.32], [-5 19.69],'color','k','linestyle',':','LineWidth',2)
% line ([-4 6.32],[19.69 19.69],'color','k','linestyle',':','LineWidth',2)
% title('x vs f(x)','FontSize',16)
% xlabel('x','FontSize',16)
% ylabel('f(x)','FontSize',16,'Rotation',0)

%p9_b
   x = linspace(-3,3,100);
%  a = linspace(-3,3,100);
%   b = linspace(-3,3,100);
%   c = linspace(-3,3,100);
%   func = (c -0.2.*b.^2+(cos(0.1.*a)+sin(0.2.*b)+cos(c).*sin(c))).^2;
  func = (x -0.2.*x.^2+(cos(0.1.*x)+sin(0.2.*x)+cos(x).*sin(x))).^2;
[nmax,maxAt,maxValues,nmin,minAt,minValues] = peakFinder(func,x);
plot(x,func,'Linewidth',2,'Color','b')
 line([1.18 1.18], [0 6.1533],'color','k','linestyle',':','LineWidth',2)
line ([-4 1.18],[6.1533 6.1533],'color','k','linestyle',':','LineWidth',2)
 title('a,b,c vs f(a,b,c)','FontSize',16)
 xlabel('a,b,c','FontSize',16)
 ylabel('f(a,b,c)','FontSize',12,'Rotation',0)
 axis tight

