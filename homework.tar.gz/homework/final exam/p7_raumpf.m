close all
clc
clear all

load cosdat;


freq = 1/(4e-8);
w = 2*pi*freq;

% ITERATION TOLERANCE
tol = 1e-6;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% PERFORM LINEAR REGRESSION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
% DETERMINE NUMBER OF MEASURED POINTS
zm = t;
fm = f;
M = length(zm);
% INITIAL GUESS
A = rand(1,1);
theta = rand(1,1);
%
% MAIN LOOP
%
err = inf;
iter = 0;
while err>tol
    % Compute Function [f]
 f = A*cos((w*zm)+theta);
 % Calculate Difference [d]
 d = fm - f;
 % FORM Z MATRIX
 fA = cos((w*zm)+theta);
 ftheta = -A.*cos((w*zm)+theta);
 Z = [ fA ftheta ];
 % Update Coefficients A and alpha
 da = (Z.'*Z) \(Z.'*d);
 A = A + da(1);
 theta = theta + da(2);
 % Calculate Relative Error
 err = abs(da./[A ; theta]);
 % Check Iteration Number
   iter = iter + 1;
  if iter>1000
   error('Did not converge.' );
  end
 end

disp([ 'A = ' num2str(A)]);
disp([ 'Theta = ' num2str(theta)]);
t1 = linspace(zm(1),zm(end),1000);
f1 = A*cos((w*t1)+theta);
figure;
plot(zm,fm)
hold on
plot(t1,f1,'--r' , 'LineWidth' ,3)
hold off
xlabel('t' );
ylabel('f(t)' );
title('f(t) VS. t');