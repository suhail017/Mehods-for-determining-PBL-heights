clc;
close all;
clear all;

%-------------------------------------------------------------------------%

A=pi/20; % there are twenty wedges

xa = linspace(-1,1,512);
ya = linspace(-1,1,512);

%-------------------------------------------------------------------------
%---creating circles for dartboards of different radii--------------------
%-------------------------------------------------------------------------

R=[14.2 31.8 184.1 203.2 304.8 323.8 ]./512;
[Y,X] = meshgrid(ya,xa);
D1 = X.^2 + Y.^2<=R(1);
D2 = X.^2 + Y.^2<=R(2);
D3 = X.^2 + Y.^2<=R(3);
D4 = X.^2 + Y.^2<=R(4);
D5 = X.^2 + Y.^2<=R(5);
D6 = X.^2 + Y.^2<=R(6);

%--creating 20 wedges with values alternating 1's and 0's------------------

wedge1=((atan2(Y,X)<=A)+(-A<=atan2(Y,X)))-1;
wedge2=((atan2(Y,X)<=5*A)+(3*A<=atan2(Y,X)))-1;
wedge3=((atan2(Y,X)<=9*A)+(7*A<=atan2(Y,X)))-1;
wedge4=((atan2(Y,X)<=13*A)+(11*A<=atan2(Y,X)))-1;
wedge5=((atan2(Y,X)<=17*A)+(15*A<=atan2(Y,X)))-1;
wedge6=flipud(wedge1);
wedge7=rot90(wedge2,2);
wedge8=rot90(wedge3,2);
wedge9=rot90(wedge4,2);
wedge10=rot90(wedge5,2);

%--------------------------------------------------------------------------

% summing up all the wedges to get wedge matrix

wedge=wedge1+wedge2+wedge3+wedge4+wedge5+...
    wedge6+wedge7+wedge8+wedge9+wedge10;

% creating dartboard matrix------------------------------------------------

D=(50.*D1+25.*(D2-D1)+20.*(D3-D2).*wedge+60.*(D4-D3).*wedge+20.*...
    (D5-D4).*wedge+40.*(D6-D5));

%------visualizing the dartboard as a contour map--------------------------


figure('Color','w');
imagesc(xa,ya,D)
title('DARTBOARD','fontsize',14)
colorbar
shading interp;
axis equal tight;

%-------------------------------------------------------------------------