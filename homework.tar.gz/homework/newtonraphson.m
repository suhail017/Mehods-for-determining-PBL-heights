%Initialize matlab

clc;
close all;
clear all;

%initialize guess
xr = 1.1;
tol=1e-4;

%function
func=@(xr) ex2func(xr);
func2=@dumbfunc2;
fxr=func(xr);
dfxr=func2(xr);

% Calculate the resolution
xa=0;
xb=5.0;
N=1000;
x=linspace(xa,xb,N);
y=func(x);
ya= min(y);
yb=max(y);



%main loop
dx=inf;
iter=0;

while abs(dx)>tol
    dx = fxr/dfxr;
    xr2 =xr-dx;
    %update iteration number
    iter=iter+1;
    
    %Visual
    subplot(3,2,iter);
    plot(x,y,'-r')
    hold on
    plot(xr,fxr,'ob');
    line ([xr xr],[fxr 0],'Color','g','linewidth',2);
    line([xa xb],[0 0]);
    line([xr xr2],[fxr 0],'Color','k','linestyle',':','linewidth',2);
    xlim([xa xb]);
      ylim([ya yb]);
    title(['Iteration' num2str(iter)],'linewidth',3);
    drawnow;
    hold off;
    legend('Function','Initial guess','evaluate the function','axes','tangent','Location','northwest');
    
    %  axis   tight;
    
    %update the root
    xr=xr2;
    
    fxr=func(xr);
    dfxr=func2(xr);
end
fprintf('The root of the function is %f\n',xr);
fprintf('Number of iteration is %d\n',iter);


