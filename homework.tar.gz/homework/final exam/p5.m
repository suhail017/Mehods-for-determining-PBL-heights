close all
clc
clear all

%Problem #a
e1 = [40 200]; % dielectric constant of material #1
e2 = 2.4;% dielectric constant of material #2
eb_n = [6 20];  % effective dielectric constant of mixture
f_n(1) = ((e2-eb_n(1))/(e2+2*eb_n(1)))/(((e2-eb_n(1))/(e2+2*eb_n(1)))- ((e1(1)-eb_n(1))/(e1(1)+2*eb_n(1)))); % fraction of the mixture that is material #1
f_n(2) = ((e2-eb_n(2))/(e2+2*eb_n(2)))/(((e2-eb_n(2))/(e2+2*eb_n(2)))- ((e1(2)-eb_n(2))/(e1(2)+2*eb_n(2))));
f_n

%Problem #b
syms eb
f1 (eb) = ((e2-eb)/(e2+2*eb))/(((e2-eb)/(e2+2*eb))- ((e1-eb)/(e1+2*eb))); % fraction of the mixture that is material #1
eb1 = finverse(f1);
xl = 0;
xu = 1;
N  = 1000; 
f = linspace(xl,xu,N);
eb = (141*f)/5 + (19881*f.^2 - 12408*f + 3136).^(1/2)/5 - 44/5;


% OPEN FIGURE WINDOW
figure('Color' , 'w' );
plot(f,eb)
h = plot(f,eb, '-b' , 'LineWidth' ,2);
h2 = get(h, 'Parent' );
set(h2, 'LineWidth' ,2,'FontSize' ,10);
xlabel('Fill Fraction, f' , 'FontSize' ,14 );
ylabel('Effective Dielectric Constact, \epsilon_B' , 'FontSize' ,14 );
title('\epsilon_B VS. f' , 'FontSize' ,18);

x = [ 0.2766 0.2766 ];
y = [ 0 6 ];
line(x,y, 'Color' , 'r' , 'LineStyle' , ' --' , 'LineWidth' ,2);
 text(0.15,9,[ ' \epsilon_B = ' num2str(6) ], 'Color' , 'r' , ...
 'HorizontalAlignment' , 'left' , 'VerticalAlignment' , 'top' , ...
 'FontSize' ,10);
x = [ 0 0.2766 ];
y = [ 6 6 ];
line(x,y, 'Color' , 'r' , 'LineStyle' , ' --' , 'LineWidth' ,2);
 text(0.28,5,[ ' f = ' num2str(0.2766) ], ...
'Color' , 'r' , 'HorizontalAlignment','left' , 'VerticalAlignment' , 'middle' , ...
 'FontSize' ,10);
