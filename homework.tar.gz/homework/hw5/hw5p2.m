%Home Work 5 Problem 3 
%Initialize matlab
clc;
clear all;
close all;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%Measured data
xm= [-0.14;0.11;0.76;1.09;1.55;1.61;2.01;2.50;2.43;2.78];
fm=[1.74;1.13;-0.52;-1.48;-1.93;-1.00;0.47;1.52;1.90;1.04];


%initial guess
A = max(fm);
omega = 1.75;
phi = 0;

%limit of x axis
xlow = 0;
xhigh = 3;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Main loop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

xh = linspace(xlow,xhigh,100);
iter = 0;
err = inf;

while err>1e-6 && iter<10
    %Visualization
    fh= A*cos((omega*xh)+phi);
    
    iter=iter+1;
    
    subplot(5,2,iter)
    
    plot(xh,fh,'-b');
    hold on
    plot(xm,fm,'or')
    hold off;
    axis  tight;
    title(['Iteration ' num2str(iter)],'Fontsize',12);
    ylabel('f(x)','Rotation',0,'Fontsize',10)
    xlabel('x','Fontsize',10)
    
    drawnow;
    
    %Evaluate function
    f= A*cos((omega*xm)+phi);
    
    %Calculated error
    d=fm(:)-f;
    
    %Form Z matrix
    z1=cos(xm*omega+phi); %derivation wrt to A
    z2=-A.*xm.*sin(omega.*xm+phi); %derivation wrt to omega
    z3= -A*sin(omega*xm+phi); %derivation wrt to phi
    Z=[z1 z2 z3];
    
    %Calculate da
    da=(Z.'*Z)\(Z.'*d);
    
    %update the curve fit
    A=A+da(1);
    phi=phi+da(3);
    omega=omega+da(2);
    
    %caluclate error
    err=max(abs(da./[A; phi;omega]));
    

     
    
    
end
fprintf('The value of the A is %f\n',A)
fprintf('The value of the phi is %f\n',phi)
fprintf('The value of the omega is %f\n',omega)

