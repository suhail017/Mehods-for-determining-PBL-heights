%homework 7 problem 2

%Initialize matlab
clc;
close all;
clear all;

% Open figure window
figure('Color','w')



%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Dashboard
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
a = -10;
b = 10;
N= 1000;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%x axis
x =linspace(a,b,N);

%filter function
f =@(x) (1+2*exp(-((x-6)/2).^2)) ;
f=f(x);
 
subplot(211)
plot(x,f,'-b','Linewidth',2)
title('The function','Fontsize',14);
 xlabel('x','Fontsize',14)
 ylabel('F(x)','FontSize',14,'Rotation',0)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Numerical derivative
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Initialzie derivative
fd = zeros(1,N);

%Grid spaces
h = x(2)-x(1);

% calculate the first point
fd(1) =(35*f(1)-104*f(2)+114*f(3)-56*f(4)+11*f(5))/(12*h^2);
fd(2) = (11*f(1)-20*f(2)+6*f(3)+4*f(4)-f(5))/(12*h^2);
%intermediate points

for n=3:N-2
fd(n) = -(f(n-2)-16*f(n-1)+30*f(n)-16*f(n+1)+f(n+2))/(12*h^2);



end

%calculate the last point

fd(N-1) = (-f(N-4)+4*f(N-3)+6*f(N-2)-20*f(N-1)+11*f(N))/(12*h^2);
fd(N) = (11*f(N-4)-56*f(N-3)+114*f(N-2)-104*f(N-1)+35*f(N))/(12*h^2);

%Plot the dreivative
 subplot(212)
 plot(x,fd,'-r','Linewidth',2)
ylim([-1 1]);
title(' Approximate second order derivative','FontSize',14)
xlabel('x','Fontsize',14)
 ylabel('F(x)','FontSize',14,'Rotation',0)

 