function [DX,DX2] = tlder(Nx,dx)
%FDDER1D              One-Dimensional Finite-Difference Derivation                     
DX = sparse(Nx,Nx);
DX =spdiags(-ones(Nx,1),-1,DX); %putting negetive one in sparse matrix
DX =spdiags(ones(Nx,1),1,DX); %Puttng positive one in 
DX= DX/(2*dx);
% fprintf ('The first derivative is\n');
% disp(full(DX));

DX2 = sparse(Nx,Nx);
DX2 =spdiags(ones(Nx,1),-1,DX2); %putting positive one in sparse matrix
DX2 =spdiags(ones(Nx,1),+1,DX2); %putting positive one in sparse matrix
DX2 =spdiags(-2*ones(Nx,1),0,DX2); %putting negetive two in sparse matrix
DX2 = DX2/(dx)^2;
% fprintf ('The Second derivative is\n');
% disp(full(DX2));
end

t