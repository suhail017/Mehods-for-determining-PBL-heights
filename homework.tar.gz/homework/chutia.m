%Initialize matlab
clc;
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASHboard
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x0= 1.1; %Initial guess
maxiter = 100;
error =1e-4;
iter=0;
dx=inf;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function to evaluate
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% syms 'x'
% f(x) = exp(x)-x-5;
% df(x) = diff(f);

% f=@(x)  exp(x)-x-5;
% df=@(x)exp(x)-1;
func=@dumbfunc;
func2=@dumbfunc2;
fxr=dumbfunc(x0);
dfxr=func2(x0);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Main loop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while abs(dx)> error
dx=(fxr/dfxr);
x1 = x0- dx;

iter = iter+1;
x0 = x1;

fxr=dumbfunc(x0);
dfxr=func2(x0);

end

x0
