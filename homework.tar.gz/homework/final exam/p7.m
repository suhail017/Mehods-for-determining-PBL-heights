


% EE 4386/5301 Computational Methods
% INITIALIZE MATLAB
close all;
clc;
clear all;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DATA FILE
file_name = 'cosdat';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PERFORM NONLINEAR REGRESSION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LOAD DATA FROM FILE
load(file_name);
N = length(t);
% CONVERT DATA TO COLUMN VECTORS
t = t(:);
f = f(:);
freq = 1/N;
% MAKE AN INTELLIGENT GUESS AT A, B, AND C
A = max(f);
omega = 2*pi*freq;
theta =0;
return
%
% MAIN LOOP
%
while 1
% Evaluate Function
fi = A*cos(omega*t+theta);
% Calculate Error
d = f - fi;
% Build Z Matrix
z1 = ones(N,1);
z2 = cos(omega*t);
z3 = cos(theta).*z2;
Z = [ z1 z2 z3 ];
% Calculate Coefficient Delta
da = (Z.'*Z)\(Z.'*d);


% Update Coefficients

A = A + da(1);
omega = omega + da(2);
theta = theta + da(3);
% Check if Done
if max(abs(da))<1e-6
break;
end
end

return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DRAW PRETTY FIGURE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OPEN FIGURE WINDOW
figure('Color','w');
hold on;
% PLOT RAW DATA
h = plot(t,f,'.b');
% CALCULATE AND PLOT CURVE FIT
f2 = A + B*exp(-C*t);
plot(t,f2,'-w','LineWidth',4);
plot(t,f2,'-r','LineWidth',2);
% ADD LATEX EQUATION
eq = [ '$$ f(t)=' num2str(A,'%6.4f') '+' num2str(B,'%6.4f') ...
'\exp(-' num2str(C,'%6.4f') 't) $$' ];
text(07,6,eq,'Interpreter','latex','FontSize',18)
% SET GRAPHICS VIEW
hold off;
axis equal tight;
h2 = get(h,'Parent');
set(h2,'LineWidth',2,'FontSize',18);
xlabel('Time t (seconds)');
ylabel('Voltage');
title('RAW DATA AND CURVE FIT','FontSize',20);