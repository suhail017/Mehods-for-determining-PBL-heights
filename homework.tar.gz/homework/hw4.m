clc;
close all;
clear all;

%Initialize matlab
i = 0;
p0 = 1.1;            %initial values
N = 1000;                %maximum number of iterations
error = 0.01;         %precision required

%function to evaluate
syms 'x'
f(x) = exp(x)-x-5;      %function we are solving
df = diff(f);           %differential of f(x)


%Main loop

while i <= N
    p = p0 - (f(p0)/df(p0));          %Newton-Raphson method 
    
    if (abs(p - p0)/abs(p)) < error                     %stopping criterion when difference between iterations is below tolerance
        fprintf('Solution is %f \n', double(p))
        return
    end
 
    i = i + 1;
    p0 = p;             %update p0
end

fprintf('Solution did not coverge within %d iterations at a required precision of %d \n', N, error)     %error for non-convergence within N iterations

