% HW9_Prob2.m
%
% Homework #9, Problems #2 and #3
% Computational Methods in EE
% University of Texas at El Paso
% Instructor: Dr. Raymond C. Rumpf
% INITIALIZE MATLAB


close all;
clc;
clear all;

% UNITS
centimeters = 0.01;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BOUNDARY CONDITIONS
z1 = 0 * centimeters; 
Va = 2;
z2 = 1 * centimeters; 
Vb = 6;

% NUMBER OF GRID POINTS
Nz = 100;

% Calculate Grids

z = linspace(z1,z2,Nz);
dz = z(2)-z(1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
c = ((z-z1)/(z2-z1));
f = (1+10*sin(pi*c));
%Construct Epsilon

Er = f;

% Calculate Derivative Z
% calculate the first and second  point
dEr(1) =(-25*f(1)+48*f(2)-36*f(3)+16*f(4)-3*f(5))/(12*dz);
dEr(2) = (-3*f(1)-10*f(2)+18*f(3)-6*f(4)+f(5))/(12*dz);

for n = 3:Nz-2
    dEr(n) = (f(n-2)-8*f(n-1)+8*f(n+1) -f(n+2))/(12*dz) ;
    
end


%calculate the last two points

dEr(Nz-1) = (-f(Nz-4)+6*f(Nz-3)-18*f(Nz-2)+10*f(Nz-1)+3*f(Nz))/(12*dz);
dEr(Nz) = (3*f(Nz-4)-16*f(Nz-3)+36*f(Nz-2)-48*f(Nz-1)+25*f(Nz))/(12*dz);

% Construct the diagonal Matrices:

ER = diag(Er);
ERD = diag(dEr);

% Construct derivative operators

[DZ,DZ2] = fdder1d(Nz,dz);


% Constructing the matrix A
A = (ER*(DZ2)+(ERD*DZ));

%modification to apply the bc

A(1,:) = 0;
A(1,1) = 1;
A(Nz,:) = 0;
A(Nz,Nz) = 1;

% Initialize the vector b
b = zeros(Nz,1);

%incorporate the boundary conditions

b(1) = Va;
b(Nz) = Vb;



v = A\b;
% figure
% plot(z,v)
% axis  tight

% xlabel('z')
% ylabel('V','Rotation',0)

% Plot Function
fig = figure('Color','w');
h = plot(z,v,'-b','LineWidth',2);
axis tight
% Set Graphics View
h2 = get(h,'Parent');
set(h2,'FontSize',14,'LineWidth',2);
xlabel('z');
ylabel('v ','Rotation',0);
% Set Tick Markings
xm = [0:0.001:0.01];
xt = {};
for m = 1 : length(xm)
xt{m} = num2str(xm(m));
end
set(h2,'XTick',xm,'XTickLabel',xt);
ym = [2:0.5:6];
yt = {};
for m = 1 : length(ym)
yt{m} = num2str(ym(m));
end
set(h2,'YTick',ym,'YTickLabel',yt);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Problem #3:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Opening a Figure Window
figure('color','w');

%subplot for the device)
subplot(1,4,1)

%RGB value for Copper
copper = [0.72 0.45 0.20];

%Draw The bottom Plate
x1 = z1; x2 = z2;
y1 = z1 - ((z2 - z1)/20); 
y2 = z1;
x = [x1 x2 x2 x1];
y = [y2 y2 y1 y1];
fill(x,y,copper);
hold on
% Draw the upper Plate

x3 = z1; x4 = z2;
y3 = z2; y4 = z2 + ((z2 - z1)/20);
x_new = [x3 x4 x4 x3];
y_new = [y4 y4 y3 y3];
fill(x_new,y_new,copper);


%draw the Di electric Materials
n = z1:(0.1*centimeters):z2;

for nz = 1:length(n)
    x_d = [x1 x2 x2 x1];
    y_d = [y2 y2 y3 y3];    
    f(nz) = 0.1 + 0.9*((Er(nz)-min(Er))/(max(Er)-min(Er)));
    color = (1-f(nz))*[1 1 1] + f(nz)*[0 1 0] ;
    fill(x_d,y_d,color);
end
title('DEVICE')
hold off
axis off

%first Subplot 
subplot(1,4,2)
plot(Er,z/centimeters,'color','g','LineWidth',2.5)
xlabel('\epsilon_r(z)')
ylabel('z(cm)')
title('PERMITTIVITY')
xlim([min(Er) max(Er)])
ylim([-0.05 1.05]);

subplot(1,4,3)
plot(dEr,z/centimeters,'color','b','LineWidth',2.5)
xlabel('d\epsilon_r(z)/dz')
ylabel('z(cm)')
title('DERIVATIVE')
xlim([min(dEr) max(dEr)])
ylim([-0.05 1.05]);

 subplot(1,4,4)
plot(v,z/centimeters,'color','r','LineWidth',2.5)
xlabel('V(z)')
ylabel('z(cm)')
title('POTENTIAL')
xlim([Va Vb])
ylim([-0.05 1.05]);


