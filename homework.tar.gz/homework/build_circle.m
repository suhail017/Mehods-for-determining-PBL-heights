% %build a circle
% 
% clc
% clear all;
% close all;
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% DASH BOARD
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% 
% %Grid Parameters
% 
% Sx=10;
% Sy=10;
% Nx = 100;
% Ny=100;
% 
% % Donut Parameters
% 
% R1 = 4.7;
% R2 = 3;
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% Compute Grid
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% 
% %grid resolution
% dx= Sx/Nx;
% dy=Sy/Ny;
% 
% %Axes
% xa= [0:Nx-1]*dx;
% ya = [0:Ny-1]*dy;
% 
% xa = xa- mean(xa);
% ya = ya - mean(ya);
% 
% 
% %Setup the mesh grid
% 
% [Y,X] = meshgrid(xa,ya);
% 
% Theta = atan2(Y,X);
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% Donut
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% %Create circles
% 
% % C1 = (X.^2 + Y.^2 ) <= R1.^2;
% % 
% % C2 = (X.^2 + Y.^2 ) <= R2.^2;
% % 
% % DN= C1-C2;
% % 
% % DN=DN.*Theta;
x0=0;
y0=0;
theta =30;
r=7;

a1 = 2*pi;  % A random direction
   a2 = a1 + theta;
   t = linspace(a1,a2);
   x = x0 + r*cos(t);
   y = y0 + r*sin(t);
   plot([x0,x,x0],[y0,y,y0],'y-')
   axis equal

%show data

% imagesc(xa,ya,DN');
% axis equal tight
% colorbar