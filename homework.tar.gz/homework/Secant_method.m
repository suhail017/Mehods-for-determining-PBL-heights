%Initialzie matlab
clc;
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Dashboard
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%Input arguements

z=[0;0;0];
v1=[1;0;0];
v2=[0;1;0];
v3=[0;0;1];

%Draw a box in 3d dimension



hold on;
%Front face
p1 =z;
p2=z+v1;
p3=p2+v3;
p4=p3-v1;
P=[p1 p2 p3 p4];
X= P(1,:);
Y=P(2,:);
Z=P(3,:);
fill3(X,Y,Z,'g');

hold on;


%Back face
X1=X-v2(1);
Y1=Y-v2(2);
Z1=Z-v2(3);

% p1 =z;
% p2=z+v1;
% p3=p2+v3;
% p4=p3-v1;
% P=[p1 p2 p3 p4];
% X= P(1,:);
% Y=P(2,:);
% Z=P(3,:);
 fill3(X1,Y1,Z1,'g');
 hold off;
 axis equal tight;
 view(-30,28);
 
 
 %Top face
 
 %Front face
p1 =z;
p2=z+v1;
p3=p2+v3;
p4=p3-v1;
P=[p1 p2 p3 p4];
X= P(1,:);
Y=P(2,:);
Z=P(3,:);
fill3(X,Y,Z,'r');