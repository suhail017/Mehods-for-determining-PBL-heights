%Problem 8

close all
clc
clear all

meters = 1;
micrometer = 1e-6;
millimeters = 1e-3;

% CONSTANTS
u0 = 1.2566370614e-6 * 1/meters;
e0 = 8.8541878176e-12 * 1/meters;
c0 = 299792458 * meters;

% GRID PARAMETERS
Sx = 20 * millimeters; %physical size of grid along x
Sy = 15 * millimeters; %physical size of grid along y
Nx = 1000; %number of grid points along x
Ny = 1000; %number of grid points along y

% INITIALIZE RESOLUTION
dx = Sx/Nx; %grid cell size along x
dy = Sy/Ny; %grid cell size along y


% 2X GRID
Nx2 = 2*Nx;
Ny2 = 2*Ny;
dx2 = dx/2;
dy2 = dy/2;

% CREATE CYLINDER
r1 = 285*micrometer;
r2 = 1.83*millimeters;
r3 = 2.03*millimeters;
er1 = 2.29;

xa = [0:Nx-1]*dx;
ya = [0:Ny-1]*dy;
xa = xa - mean(xa);
ya = ya - mean(ya);
[Y,X] = meshgrid(ya,xa);

xa2 = [0:Nx2-1]*dx2;
ya2 = [0:Ny2-1]*dy2;
xa2 = xa2 - mean(xa2);
ya2 = ya2 - mean(ya2);
[Y2,X2] = meshgrid(ya2,xa2);

RSQ = (X.^2 + Y.^2);
RSQ2 = (X2.^2 + Y2.^2);
% BUILD INNER CONDUCTOR
CIN = (RSQ<=r1^2);

% BUILD OUTER CONDUCTOR
COUT = (RSQ<r3^2 & RSQ>=r2^2);


% BUILD DIELECTRIC
ER2 = ones(Nx2,Ny2); %air
ER2 = ER2 + (er1-1)*(RSQ2<r2^2 & RSQ2>=r1^2); %dielectric 1

% EXTRACT ERxx AND ERyy FROM ER2
ERxx = ER2(2:2:Nx2,1:2:Ny2);
ERyy = ER2(1:2:Nx2,2:2:Ny2);

% FORM DIAGONAL PERMITTIVITY MATRICES
ERxx = diag(sparse(ERxx(:)));
ERyy = diag(sparse(ERyy(:)));

% FORM PERMITTIVITY TENSOR
Z = sparse(Nx*Ny,Nx*Ny);
ER = [ ERxx , Z ; Z , ERyy ];

% CALL FUNCTION TO CONSTRUCT DERIVATIVE OPERATORS
NS = [Nx Ny]; %grid size
RES = [dx dy]; %grid resolution
[DVX,DVY,DEX,DEY] = tlder(NS,RES); %build matrices
L = [DEX DEY] * ER * [DVX ; DVY];
Lh = [DEX DEY] * [DVX ; DVY];
% FORCE MATRIX
F = CIN | COUT;
F = diag(sparse(F(:)));
% FORCED POTENTIALS
vf = 1*CIN + 0*COUT;
M = Nx*Ny;
% FORCE KNOWN POTENTIALS
I = speye(size(F));
L = (I - F)*L + F;
Lh = (I - F)*Lh + F;
b = F*vf(:);
% COMPUTE POTENTIALS
v = L\b;
vh = Lh\b;
% COMPUTE E FIELDS
e = - [ DVX ; DVY ] * v;
eh = - [ DVX ; DVY ] * vh;
% COMPUTE D FIELDS
d = ER*e;
dh = eh;
% DISTRIBUTED CAPACITANCE
C = e0*d'*e*dx*dy;
% DISTRIBUTED INDUCTANCE
Ch = e0*dh'*eh*dx*dy;
L = 1/(c0^2*Ch);
% CHARACTERISTIC IMPEDANCE
Z0 = sqrt(L/C);
% EFFECTIVE REFRACTIVE INDEX
neff = c0*sqrt(L*C);
disp([ 'DISTRIBUTED CAPACITANCE,C = ' num2str(C*meters) ' F/m' ]);
disp([ 'DISTRIBUTED INDUCTANCE,L = ' num2str(L*meters) ' H/m' ]);
disp([ 'CHARACTERISTIC IMPEDANCE,Z0 = ' num2str(Z0) ' Ohms' ]);




