
clc
clear all
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Dasboard
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0 = 0;
y0 = 0;
x = [x0; y0];

y = (3.5*x + 2*y + x.^2 - x.^4 - 2*x*y - y.^2);

% xL = 0;
% xU = 14;
% x = linspace(xL,Xu,100);
% y = (1 - 2*x - x.^2 - 2*x.^3 + 0.15*x.^4) ;

[nmax,maxAt,maxValues,nmin,minAt,minValues] = peakFinder(y,x)