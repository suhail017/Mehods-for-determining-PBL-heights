%Problem 10

% Initialize Matlab
clc;
clear all;
close all

%%%%%%%%%%%%%%%%%%%%%%%%
%% Dashboard
%%%%%%%%%%%%%%%%%%%%%%%%

% CREATE A FUNCTION

f = [ zeros(1,100) linspace(0,1,100) linspace(1,0,100) ...
    zeros(1,99) ];
N = length(f);
x = linspace(-2,2,N);

 % PLOT FUNCTION
subplot(2,1,1);
plot(x,f,'Color','g','LineWidth',2);
xlabel('x','FontSize',14 );
ylabel('t(x)','FontSize',14 );
title('t(x) VS. x','FontSize',14);
xlim([min(x) max(x)]);


%Plot the 
NA = 3;
A = 0:0.5:1;
FD_DAT = zeros(N,NA);

CM = colormap(jet(NA));

for na = 1 : NA
    
    % Get a
    a = A(na);
    
    % CALCULATE FRACTIONAL DERIVATIVE
    L = max(x) - min(x);
    k = (2*pi/L) * [ -floor(N/2) : floor(N/2) ];
    F = fftshift(fft(f));
    F = (1i*k).^a .* F;
    fd = real(ifft(ifftshift(F)));
    
    % Record Answer
    FD_DAT(:,na) = fd;
    
    % PLOT FFT
    subplot(2,1,2);
    line(x,a*ones(1,N),fd,'Color','r','LineWidth',2);
    xlabel('x axis','FontSize',14);
    ylabel('a','FontSize',14);
    axis  tight
    h = zlabel('d^af(x)/dx^a','FontSize',14);
    title('d^af(x)/dx^a VS. x','FontSize',14);
     view(122,56);
    drawnow;
    hold on;
    
end





