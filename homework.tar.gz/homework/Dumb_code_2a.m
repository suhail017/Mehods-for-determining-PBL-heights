%Dumb_code_2a
%Initialize matlab
close all;
clc;
clear all;

%Setup axes
xa=linspace(-1,1,512);
ya=linspace(-1,1,512);

%Setup meshgrid
[X Y] = meshgrid(xa,ya);

%Build a circle
R=0.425;
CIR= X.^2 + Y.^2 <R.^2;
CIR=CIR*20;

R4= 0.245;
EYE4 =  X.^2 + Y.^2 <R4.^2;
EY4 = EYE4.*40;
% CIR = X < 50;

 R3=0.156;
 EYE3 = X.^2 + Y.^2 <R3.^2;
 EY3 = EYE3.*50;
 
 R2=0.011;
 EYE2 = X.^2 + Y.^2 < R2.^2;
 EY2 = EYE2.*60;

 F= (CIR-EYE4-EYE3-EYE2);
 board = F + EY2 + EY3 + EY4;
 imagesc(xa,ya,F);
 %colormap jet;


THETA = atan2(Y,X);
THETA = THETA -min(THETA(:));
THETA = THETA /max(THETA(:));
THETA = ceil (20*THETA);

 A= board.*THETA;

figure(2)
imagesc(xa,ya,A');
%colormap jet;
colorbar;
axis equal tight;