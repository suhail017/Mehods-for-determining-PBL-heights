clc;
clear; 
close all
steps = 5;                                      % number of steps
x = linspace(0,10,steps);                  % create data
xs = linspace(0,10,2*steps+1);                % sample points
f = hw6func(x);
fs = hw6func(xs);                                   % sample function
c = zeros(steps,3);                                  
for k = 1:steps
     c(k,:) = polyfit(xs(2*k-1:2*k+1),fs(2*k-1:2*k+1),2); %fit coefficients
     hold on
     z = linspace(xs(2*k-1),xs(2*k+1),5);
     y = c(k,1).*z.^2+c(k,2).*z+c(k,3);
     area(z,y,'FaceColor',[0.5,1,1])
end
 hold on
 plot(x,f,'g','LineWidth',2)  
 hold on
plot(xs,fs,'bo','LineWidth',2)                   % plot sample points
title('The Visualization of Simpson Method','FontSize',14)
xlabel ('x','FontSize',12)
ylabel('F(x)','FontSize',12,'Rotation',0)




% line([1 1],[0 100],'color','b','linewidth',3);
% hold all
%  verts = [[0;3],[100;100]];
%  faces = [1 2 3 4];
%  cdata = [1 0 0];
%  p = patch('Faces',faces,'Vertices',verts,'FaceColor','flat',...
%            'FaceVertexCData',cdata,'edgecolor','none');
%  axis([0 4 0 100])