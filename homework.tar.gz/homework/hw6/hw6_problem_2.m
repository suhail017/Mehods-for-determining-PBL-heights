%hw6_problem_2


%Simpson
%Initialize matlab
clc;
clear all;
close all;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Number of points in integration
N=1000;

%define function and limits

func=@hw6func;
a=0.987655;
b=3.210989;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Simpson rule
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%calculate points


x=linspace(a,b,N);
y=func(x);
dx=x(2)-x(1);

%numerical integration

A=0;
for n=1:2:N-2
 a = 1*y(n)+4*y(n+1)+y(n+2);
 A=A+a;



end


A=A*dx*1/3;
fprintf('The integration is %.6f\n',A);

plot(x,y)