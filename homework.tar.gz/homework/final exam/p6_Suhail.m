%final exam
%p6

%Initialize Matlab
clc
clear all
close all



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Dashboard
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%define boundary values

xa = -1.5;
xb = 1.5;
fa = -1;
fb = 1;

%Numerical Parameters

Nx = 1000;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Implementation of FDM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Setup grid

x = linspace(xa,xb,Nx);
dx = x(2)- x(1);

%Build derivative matrices (using drichlet boundary conditions)

Z = sparse(Nx,Nx);


DX = Z;
DX =spdiags(-ones(Nx,1),-1,DX); %putting negetive one in sparse matrix
DX =spdiags(ones(Nx,1),1,DX); %Puttng positive one in 
DX= DX/(2*dx);


D2X = Z;
D2X =spdiags(ones(Nx,1),-1,D2X); %putting positive one in sparse matrix
D2X =spdiags(ones(Nx,1),+1,D2X); %putting positive one in sparse matrix
D2X =spdiags(-2*ones(Nx,1),0,D2X); %putting negetive two in sparse matrix
D2X = D2X/(dx)^2;
full(D2X);


%Build matrix equation
I = speye(Nx,Nx);
A = D2X - 2*I*DX+3*I;
b=zeros(Nx,1);

%Incorpoorate boundary values
A(1,:) = 0;
A(1,1)=1;
b(1)=fa;


A(Nx,:) = 0;
A(Nx,Nx)=1;
b(1)=fa;
b(Nx) = fb;

%solve
f = full(A\b)

figure('Color' , 'w' );
plot(x,f, ' -b' , 'LineWidth' ,2);
xlabel('x','FontSize',12 );
ylabel('f(x)','FontSize',12,'Rotation',0 );
title('f(x) VS. x','FontSize',12);




% Problem b

