close all;
clc;
clear all;
 
f = @(x)ex2func(x)-2;
tol = 1e-6;
 
%Initial Values
x1 = [0 2 5];
x2 = [1 3 10];
 
%Secant Method
disp('      Secant Method');
disp('Iteration        Root');
disp('=======================');
[IterationA,a] = secant_method(f,x1(1),x2(1),tol);
fprintf('\n    %1d          %0.10f\n',IterationA,a);
[IterationB,b] = secant_method(f,x1(2),x2(2),tol);
fprintf('\n    %1d          %0.10f\n',IterationB,b);
[IterationC,c] = secant_method(f,x1(3),x2(3),tol);
fprintf('\n    %1d          %0.10f\n',IterationC,c);
plot(x1,f(x1))