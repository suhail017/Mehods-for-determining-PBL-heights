%Initialize matlab

clc;
close all;
clear all;

%%%%%%%%%%%%%%%%%%%%%%%%%
%% Dashboard
%%%%%%%%%%%%%%%%%%%%%%%%
XDAT={'A' 'B' 'C' 'D' 'E'};
YDAT=[5 15 10 3 2];
bar(1:length(XDAT),YDAT);