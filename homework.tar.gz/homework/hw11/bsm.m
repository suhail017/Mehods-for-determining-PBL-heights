%Bisection and False Position method
%Submitted by Suhail Mahmud
%ID 80539798

%INITIALIZE MATLAB
clc;
clear all;
close all;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Define function
w= 3;
h=2;


%Define limits
er1=0.0;  %lower limits
er2= 10;  %uppper limits
func=@microstrip;
%COnvergence tolerance
tol = 1e-4;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Implement the method
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Evauate the functiom
fL=func(er1);
fU=func(er2);

%Check bounds
if fL*fU>0
    error('No roots or multiple roots found');
end


%First guess at root
xr=(er1+er2)/2;



%Calculate the resolution
dx= er2-er1;
xa = er1 - 0.05*dx;
xb = er2 + 0.05*dx;
x= linspace(xa,xb,1000);
y=func(x);
ya= min(y);
yb=max(y);




%Main loop

iter = 0;

err=Inf;
while  err > tol
    
    %update the iteration number
    iter=iter+1;
    
    %calculate function at xr
    fr=func(xr);
    
    %Show status
    % figure('Color','r')
    %suptitle('Using the False Position method\n')
    
    % subplot(5,2,iter);
    % plot(x,y,'-r');
    % hold on;
    % plot([xL xr er2],[fL fr fU],'ob');
    % line([xL xL],[ya yb]);
    % line([er2 er2],[ya yb]);
    % line([xa xb],[0 0]);
    % xlim([xa xb]);
    % ylim([ya yb]);
    % title(['Iteration' num2str(iter)]);
    % drawnow;
    % hold off;
    % %
    
    %adjust bound
    if fL*fr<0
        er2=xr;
        fU= fr;
    elseif fL*fr>0
        er1=xr;
        fL=fr;
    else
        break
    end
    
    
    %uppdate guess at root
    xr2= (er2+er1)/2;
    %    xr2 = ((xL+xU)/2)-((fU+fL)*(xU-xL)/(2*(fU-fL)));
    
    err = abs((xr2-xr)/xr2);%test for convergence
    xr=xr2;
    
end

fprintf('The root of the given function is %2f\n',xr);
fprintf('The iteration number is %2d\n',iter);






