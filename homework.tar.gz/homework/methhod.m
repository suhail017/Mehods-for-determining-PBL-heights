%demo least square
%INITIALIZE MATLAB
clc;
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%number of points
N=20;

%Number 
xm=[0 2 3];
ym=[6 8 2];

%STEP 1
M=length(xm);
f=ym(:);
X=[ones(M,1) , xm(:) ,xm(:).^2];
a=X\f;
%Calculate the polynomial
xh=linspace(-1,4,1000);
yh=a(1)+a(2)*xh+a(3)*xh.^2;

plot(xh,yh)
