function [Iteration,x2] = secant_method(f,x1,x2,tol)

Iteration = 0;

%Midpoint
f1 = f(x1);
f2 = f(x2);
delta_x = f2*(x2 - x1)/(f2 -f1);

while (abs(delta_x)>tol)
    Iteration = Iteration + 1;
    x1 = x2;
    f1 = f2;
    x2 = x1 - delta_x;
    f2 = f(x2);
    delta_x = f2*(x2 - x1)/(f2 -f1);
end
end
