function y1=dumbfunc2(x)
 y1=exp(x)-1;
 
% y1=cot(x);
%  y1=2*x+1;
end
