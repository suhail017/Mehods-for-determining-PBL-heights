% Home Work problem 2.3
% Submitted by Suhail Mahmud
%ID 80539798

%Initialize Matlab

clc;
clear all;
close all;

meters = 1;
centimeters = 1e-2 * meters;
millimeters = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DASH BOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xa=425.5*2* millimeters;

ya=425.5*2* millimeters;

Nx = 512;

Ny = 512;


%Setup axis

dx = round(xa/Nx);
dy = round(ya/Ny);

xa = (0:Nx - 1)*dx;
xa = xa - mean(xa);
ya = (0:Ny - 1)*dy;
ya = ya - mean(ya);

%Setup meshgrid

[X , Y] = meshgrid(xa,ya);

%Making the wedges

THETA = atan2(Y,X);
THETA = THETA -min(THETA(:));
THETA = THETA /max(THETA(:));
THETA = ceil ((19*THETA) +0.1);

%Find the indices and replace

ind = find(THETA(:) == 0);
THETA(ind) = 1;

ind = find(THETA(:) ==1);
THETA(ind) = 18;


ind = find(THETA(:) ==2);
THETA(ind) = 4;

ind = find(THETA(:) ==3);
THETA(ind) = 13;

ind = find(THETA(:) ==4);
THETA(ind) = 6;


ind = find(THETA(:) ==5);
THETA(ind) = 10;

ind = find(THETA(:) ==6);
THETA(ind) = 15;

ind = find(THETA(:) ==7);
THETA(ind) = 2;

ind = find(THETA(:) ==8);
THETA(ind) = 17;

ind = find(THETA(:) ==9);
THETA(ind) = 3;


ind = find(THETA(:) ==10);
THETA(ind) = 19;

ind = find(THETA(:) ==11);
THETA(ind) = 7;

ind = find(THETA(:) ==12);
THETA(ind) = 16;

ind = find(THETA(:) ==13);
THETA(ind) = 8;

ind = find(THETA(:) ==14);
THETA(ind) = 11;

ind = find(THETA(:) ==15);
THETA(ind) = 14;

ind = find(THETA(:) ==16);
THETA(ind) = 9;

ind = find(THETA(:) ==17);
THETA(ind) = 12;

ind = find(THETA(:) ==18);
THETA(ind) = 5;

ind = find(THETA(:) ==19);
THETA(ind) = 20;


% imagesc(xa,ya,THETA');
% return


% Making the circles

CIR= X.^2 + Y.^2;
cir7=ones(Nx,Ny);
 
cir7= cir7.*THETA;


r6 = 323.8 *millimeters;
cir6 = CIR>r6^2;
cir7(cir6) = 0;  %The outermost circle

r5 = 304.8*millimeters;
cir5 = CIR<r6^2 & CIR>=r5^2;
cir7(cir5) = 2*THETA(cir5);

r4 = 203.2*millimeters;
 cir4 = CIR<r5^2 & CIR>=r4^2;
 cir7(cir4) = THETA(cir4);

r3 = 184.1*millimeters;
cir3 = CIR<r4^2 & CIR>=r3^2;
cir7(cir3) = 3*THETA(cir3);

r2 = 31.8*millimeters;

r1 = 14.2*millimeters;

cir1 = CIR<r2^2 & CIR>=r1^2;
cir7(cir1) = 25;

cir0 = CIR<r1^2;
cir7(cir0) = 50; %inner most circle


%visualization

figure('Color','w');
imagesc(xa,ya,cir7');
colormap (gray);
colorbar;
axis equal tight;
xlabel('x');
ylabel('y ','Rotation',0);
title ('DARTBOARD','Fontsize',14)

