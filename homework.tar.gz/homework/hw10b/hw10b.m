%Initialize Matlab
clc
clear all
close all

% HW10b.m
%
% EE 4386/5301 Computational Methods in EE
% University of Texas at El Paso
% Instructor: Dr. Raymond C. Rumpf
% INITIALIZE MATLAB
close all;
clc;
clear all;
% UNITS
millimeters = 1;
meters = 1e3 * millimeters;
% CONSTANTS
u0 = 1.2566370614e-6 * 1/meters;
e0 = 8.8541878176e-12 * 1/meters;
c0 = 299792458 * meters;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% STEP 1 -- DASHBOARD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TRANSMISSION LINE PARAMETERS
er = 6.0; %dielectric constant of substrate
h = 2 * millimeters; %thickness of substrate
w = 3 * millimeters; %width of signal line


% GRID PARAMETERS
Sx = 21 * millimeters; %physical size of grid along x
Sy = 14 * millimeters; %physical size of grid along y
Nx = 128; %number of grid points along x
Ny = 85; %number of grid points along y



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Step 2 build materials arrray
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Initail guess at resoultaion
dx = Sx/Nx;
dy = Sy/Ny;


%Snap grid to critical dimension

nx =ceil( w/dx);
dx = w/nx;

ny = ceil(h/dy);
dy = h/ny;


%recalculate the size
Sx = Nx*dx;
Sy = Ny*dy;

%Grid axis
xa = [0:Nx-1]*dx;
xa = xa-mean(xa);
ya = [0:Ny-1]*dy;
ya = ya-mean(ya);


%Build ground
GND = zeros(Nx,Ny);
GND([1 Nx],:) = 1;
GND(:,[1 Ny]) = 1;

%Build Sig
SIG = zeros(Nx,Ny);
nx = round(w/dx);
nx1 = 1+floor((Nx-nx)/2);
nx2 = nx1+nx-1;
ny = round(h/dy);
ny = Ny-ny-1;
SIG(nx1:nx2,ny) = 1;


%Build ERxx and ERyy

ERxx = ones(Nx,Ny);
ERxx(:,ny+1:Ny) = er;
ERyy = ERxx;
% %Show arrays
% subplot(221);
% imagesc(xa,ya,GND');
% axis equal tight
% colorbar
% title('GND','FontSize',14)
%
%
% subplot(222);
% imagesc(xa,ya,SIG');
% axis equal tight
% colorbar
% title('SIG','FontSize',14)
%
% subplot(223);
% imagesc(xa,ya,ERxx');
% axis equal tight
% colorbar
% title('ERxx','FontSize',14)
%
%
% subplot(224);
% imagesc(xa,ya,ERyy');
% axis equal tight
% colorbar
% colormap('Gray')
% title('ERyy','FontSize',14)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 2x grid technique
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 2X GRID
Nx2 = 2*Nx;
Ny2 = 2*Ny;
dx2 = dx/2;
dy2 = dy/2;

ER2 = ones(Nx2,Ny2);
ER2(:,2*(ny-1)+1:Ny2) = er;

% EXTRACT 1X GRID PARAMETERS
ERxx = ER2(2:2:Nx2,1:2:Ny2);
ERyy = ER2(1:2:Nx2,2:2:Ny2);

% FORM DIAGONAL PERMITTIVITY MATRICES
ERxx = diag(sparse(ERxx(:)));
ERyy = diag(sparse(ERyy(:)));

% FORM PERMITTIVITY TENSOR
Z = sparse(Nx*Ny,Nx*Ny);
ER = [ ERxx , Z ; Z , ERyy ];

% CALL FUNCTION TO CONSTRUCT DERIVATIVE OPERATORS
NS = [Nx Ny]; %grid size
RES = [dx dy]; %grid resolution
[DVX,DVY,DDX,DDY] = tlder(NS,RES); %build matrices


L = [DDX DDY] * ER * [DVX ; DVY];
Lh = [DDX DDY] * [DVX ; DVY];

% FORCE MATRIX
F = SIG | GND;
F = diag(sparse(F(:)));

% FORCED POTENTIALS
vf = 1*SIG + 0*GND;

% FORCE KNOWN POTENTIALS
M = Nx*Ny;
I = speye(M,M);
L = (I - F)*L + F;
Lh = (I - F)*Lh + F;
b = F*vf(:);

% COMPUTE POTENTIALS
v = L\b;
vh = Lh\b;

% COMPUTE E FIELDS
e = - [ DVX ; DVY ] * v;
eh = - [ DVX ; DVY ] * vh;

ex = e(1:M);
ey = e(M+1:2*M);

% COMPUTE D FIELDS
d = ER*e;
dh = eh;

% DISTRIBUTED CAPACITANCE
C = e0*d'*e*dx*dy;
fprintf('Distributed Capacitance is %d\n ',C);

% DISTRIBUTED INDUCTANCE
Ch = e0*dh'*eh*dx*dy;
L = 1/(c0^2*Ch);
fprintf('Distributed Inductance is %d\n ',L);

% CHARACTERISTIC IMPEDANCE
Z0 = sqrt(L/C);
fprintf('CHARACTERISTIC IMPEDANCE is %d\n ',Z0);
% EFFECTIVE REFRACTIVE INDEX
neff = c0*sqrt(L*C);


% RESHAPE THE FUNCTIONS BACK TO A 2D GRID
vh = reshape(vh,Nx,Ny);
v = reshape(v,Nx,Ny);


%Visualize
imagesc(xa,ya,v');
colorbar;
title('POTENTIAL','FontSize',14)
xlabel('x(mm)','FontSize',12)
ylabel('y(mm)','FontSize',12)
axis equal tight
colormap('gray');


figure
ex = reshape(ex,Nx,Ny);
ey = reshape(ey,Nx,Ny);
e = sqrt(abs(ex).^2 + abs(ey).^2);
imagesc(xa,ya,e')
caxis([0 0.5]);
colorbar
title('ELECTRIC FIELD','FontSize',14)
xlabel('x(mm)','FontSize',12)
ylabel('y(mm)','FontSize',12)
hold on
[Y,X] = meshgrid(ya,xa);
quiver(X,Y,ex,ey);
hold off
axis equal tight
colormap('gray');
